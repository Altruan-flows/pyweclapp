from collections import namedtuple


class CAT_Article:
    
    def __init__(self, data):


        # Article - Preisgestaltung
        pass



