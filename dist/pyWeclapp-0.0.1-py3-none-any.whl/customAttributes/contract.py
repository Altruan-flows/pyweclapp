from collections import namedtuple


class CAT_Contract:
    
    def __init__(self, data):


        pass


