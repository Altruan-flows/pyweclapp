from collections import namedtuple


class CAT_Task:
    
    def __init__(self, data):


        # Task - rest
        pass



