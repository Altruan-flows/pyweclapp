class CAT_Settings:
	def __init__(self, data:dict=None):
		# You can place global cat settings here. they will not be modified
		pass
