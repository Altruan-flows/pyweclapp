# dynamic File please do not edit

from pyWeclapp.weclappClasses.weclappClassBlueprint.weclappClassCustomAttribute import WeclappMetaData
from .article_Model import Article, ArticlePrices
from .salesOrder_Model import SalesOrder, OrderItems
from .shipment_Model import Shipment, ShipmentItems
from .contract_Model import Contract, ContractItems